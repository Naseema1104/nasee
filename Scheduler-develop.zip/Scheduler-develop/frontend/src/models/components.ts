export interface ComponentProps {
	id?: string;
	className?: string;
}
