export enum Locale {
	EN = "en",
	UA = "uk",
}
