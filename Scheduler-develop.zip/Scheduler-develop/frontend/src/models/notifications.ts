export enum NotificationType {
	Success,
	Error,
}
