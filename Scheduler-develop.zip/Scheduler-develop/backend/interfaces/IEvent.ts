export interface IEvent {
	id: string;
	title: string;
	startDate: Date;
	endDate: Date;
}
