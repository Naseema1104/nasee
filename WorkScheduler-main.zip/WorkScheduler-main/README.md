# Week 5 Challenge
In the Week 5 challenge, our job is to create a functioning Work Day Scheduler. Givien the starter code, we are to create a Javascript file which will include all the functions needed to run this application.
## USER STORY
<img width="515" alt="Screen Shot 2022-01-29 at 2 41 03 PM" src="https://user-images.githubusercontent.com/94761193/151675497-c3baf97f-3d45-4bea-ab43-f746ba4ac9cf.png">

# Acceptance Criteria
<img width="505" alt="Screen Shot 2022-01-29 at 2 41 44 PM" src="https://user-images.githubusercontent.com/94761193/151675506-1c0f61fa-e09e-4854-8f81-2f4abbc7426b.png">


# Mock Up Image
<img width="384" alt="Screen Shot 2022-01-29 at 2 43 33 PM" src="https://user-images.githubusercontent.com/94761193/151675508-04aea33b-f0b4-43f2-8102-6a1159b4f49a.png">


## Details of Application
This application is made using HTML, CSS, JavaScript and Moment.JS. By using this function, you will be able to add tasks into each hour of the day, and save them. Your response will be saved when the page is reloaded.

## Completed Assignment Link
[WorkDayScheduler](https://lf56.github.io/WorkScheduler/)

# Questions

Email me for contact/questions: [Here!](leah.fox7@gmail.com)

Connect with me on GitHub: [Here!](https://github.com/LF56)
<br>
Connect with me on LinkedIn: [Here!](https://www.linkedin.com/in/leah-fox-37963b1a2/)
